﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIS160CarShow2
{
   public partial class frmCarShow : Form
   {
      public frmCarShow()
      {
         InitializeComponent();
      }

      private void lblValue_Click(object sender, EventArgs e)
      {

      }
   }
}
