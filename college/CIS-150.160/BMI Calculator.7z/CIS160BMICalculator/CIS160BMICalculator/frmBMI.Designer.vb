﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBMI
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBMI))
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.txtWeight = New System.Windows.Forms.TextBox()
        Me.txtHeight = New System.Windows.Forms.TextBox()
        Me.lstUnitSelection = New System.Windows.Forms.ListBox()
        Me.lblEnterWeight = New System.Windows.Forms.Label()
        Me.lblEnterHeight = New System.Windows.Forms.Label()
        Me.lblUnit = New System.Windows.Forms.Label()
        Me.lblUnit2 = New System.Windows.Forms.Label()
        Me.lblConversionSelection = New System.Windows.Forms.Label()
        Me.lblHeader = New System.Windows.Forms.Label()
        Me.lblResults = New System.Windows.Forms.Label()
        Me.picObese = New System.Windows.Forms.PictureBox()
        Me.picOverWeight = New System.Windows.Forms.PictureBox()
        Me.picNormal = New System.Windows.Forms.PictureBox()
        Me.picMeter = New System.Windows.Forms.PictureBox()
        Me.picUnderweight = New System.Windows.Forms.PictureBox()
        CType(Me.picObese, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picOverWeight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picNormal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMeter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picUnderweight, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnCalculate
        '
        Me.btnCalculate.Enabled = False
        Me.btnCalculate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculate.Location = New System.Drawing.Point(12, 205)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(100, 54)
        Me.btnCalculate.TabIndex = 0
        Me.btnCalculate.Text = "Calculate Body Fat %"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(163, 205)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(100, 54)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "Clear" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Data"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'txtWeight
        '
        Me.txtWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWeight.Location = New System.Drawing.Point(12, 71)
        Me.txtWeight.Name = "txtWeight"
        Me.txtWeight.Size = New System.Drawing.Size(100, 26)
        Me.txtWeight.TabIndex = 2
        Me.txtWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtHeight
        '
        Me.txtHeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHeight.Location = New System.Drawing.Point(163, 71)
        Me.txtHeight.Name = "txtHeight"
        Me.txtHeight.Size = New System.Drawing.Size(100, 26)
        Me.txtHeight.TabIndex = 3
        Me.txtHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lstUnitSelection
        '
        Me.lstUnitSelection.BackColor = System.Drawing.Color.White
        Me.lstUnitSelection.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstUnitSelection.FormattingEnabled = True
        Me.lstUnitSelection.ItemHeight = 20
        Me.lstUnitSelection.Items.AddRange(New Object() {"Metric", "Imperial"})
        Me.lstUnitSelection.Location = New System.Drawing.Point(12, 123)
        Me.lstUnitSelection.Name = "lstUnitSelection"
        Me.lstUnitSelection.Size = New System.Drawing.Size(251, 44)
        Me.lstUnitSelection.TabIndex = 4
        '
        'lblEnterWeight
        '
        Me.lblEnterWeight.AutoSize = True
        Me.lblEnterWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEnterWeight.Location = New System.Drawing.Point(8, 48)
        Me.lblEnterWeight.Name = "lblEnterWeight"
        Me.lblEnterWeight.Size = New System.Drawing.Size(106, 20)
        Me.lblEnterWeight.TabIndex = 5
        Me.lblEnterWeight.Text = "Enter Weight:"
        '
        'lblEnterHeight
        '
        Me.lblEnterHeight.AutoSize = True
        Me.lblEnterHeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEnterHeight.Location = New System.Drawing.Point(160, 48)
        Me.lblEnterHeight.Name = "lblEnterHeight"
        Me.lblEnterHeight.Size = New System.Drawing.Size(103, 20)
        Me.lblEnterHeight.TabIndex = 6
        Me.lblEnterHeight.Text = "Enter Height:"
        '
        'lblUnit
        '
        Me.lblUnit.AutoSize = True
        Me.lblUnit.Location = New System.Drawing.Point(16, 104)
        Me.lblUnit.Name = "lblUnit"
        Me.lblUnit.Size = New System.Drawing.Size(93, 13)
        Me.lblUnit.TabIndex = 7
        Me.lblUnit.Text = "Pounds/Kilograms"
        '
        'lblUnit2
        '
        Me.lblUnit2.AutoSize = True
        Me.lblUnit2.Location = New System.Drawing.Point(175, 104)
        Me.lblUnit2.Name = "lblUnit2"
        Me.lblUnit2.Size = New System.Drawing.Size(76, 13)
        Me.lblUnit2.TabIndex = 8
        Me.lblUnit2.Text = "Inches/Meters"
        '
        'lblConversionSelection
        '
        Me.lblConversionSelection.AutoSize = True
        Me.lblConversionSelection.Location = New System.Drawing.Point(59, 170)
        Me.lblConversionSelection.Name = "lblConversionSelection"
        Me.lblConversionSelection.Size = New System.Drawing.Size(157, 13)
        Me.lblConversionSelection.TabIndex = 9
        Me.lblConversionSelection.Text = "Select Imperial or Metric System"
        '
        'lblHeader
        '
        Me.lblHeader.AutoSize = True
        Me.lblHeader.Font = New System.Drawing.Font("Modern No. 20", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.Location = New System.Drawing.Point(219, 9)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(189, 29)
        Me.lblHeader.TabIndex = 10
        Me.lblHeader.Text = "BMI Calculator"
        '
        'lblResults
        '
        Me.lblResults.AutoSize = True
        Me.lblResults.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResults.Location = New System.Drawing.Point(300, 48)
        Me.lblResults.Name = "lblResults"
        Me.lblResults.Size = New System.Drawing.Size(270, 16)
        Me.lblResults.TabIndex = 11
        Me.lblResults.Text = "Enter Data to Calculate Your Fat Percentage"
        '
        'picObese
        '
        Me.picObese.Image = Global.CIS160BMICalculator.My.Resources.Resources.obesity
        Me.picObese.Location = New System.Drawing.Point(303, 71)
        Me.picObese.Name = "picObese"
        Me.picObese.Size = New System.Drawing.Size(311, 188)
        Me.picObese.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picObese.TabIndex = 16
        Me.picObese.TabStop = False
        Me.picObese.Visible = False
        '
        'picOverWeight
        '
        Me.picOverWeight.Image = Global.CIS160BMICalculator.My.Resources.Resources.overweight
        Me.picOverWeight.Location = New System.Drawing.Point(303, 71)
        Me.picOverWeight.Name = "picOverWeight"
        Me.picOverWeight.Size = New System.Drawing.Size(311, 188)
        Me.picOverWeight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picOverWeight.TabIndex = 15
        Me.picOverWeight.TabStop = False
        Me.picOverWeight.Visible = False
        '
        'picNormal
        '
        Me.picNormal.Image = Global.CIS160BMICalculator.My.Resources.Resources.normal
        Me.picNormal.Location = New System.Drawing.Point(303, 71)
        Me.picNormal.Name = "picNormal"
        Me.picNormal.Size = New System.Drawing.Size(311, 188)
        Me.picNormal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picNormal.TabIndex = 14
        Me.picNormal.TabStop = False
        Me.picNormal.Visible = False
        '
        'picMeter
        '
        Me.picMeter.Image = Global.CIS160BMICalculator.My.Resources.Resources.Picture22
        Me.picMeter.Location = New System.Drawing.Point(-1, 265)
        Me.picMeter.Name = "picMeter"
        Me.picMeter.Size = New System.Drawing.Size(628, 328)
        Me.picMeter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picMeter.TabIndex = 13
        Me.picMeter.TabStop = False
        '
        'picUnderweight
        '
        Me.picUnderweight.Image = Global.CIS160BMICalculator.My.Resources.Resources.underweight1
        Me.picUnderweight.Location = New System.Drawing.Point(303, 71)
        Me.picUnderweight.Name = "picUnderweight"
        Me.picUnderweight.Size = New System.Drawing.Size(311, 188)
        Me.picUnderweight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picUnderweight.TabIndex = 12
        Me.picUnderweight.TabStop = False
        Me.picUnderweight.Visible = False
        '
        'frmBMI
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.CancelButton = Me.btnClear
        Me.ClientSize = New System.Drawing.Size(626, 591)
        Me.Controls.Add(Me.picObese)
        Me.Controls.Add(Me.picOverWeight)
        Me.Controls.Add(Me.picNormal)
        Me.Controls.Add(Me.picMeter)
        Me.Controls.Add(Me.picUnderweight)
        Me.Controls.Add(Me.lblResults)
        Me.Controls.Add(Me.lblHeader)
        Me.Controls.Add(Me.lblConversionSelection)
        Me.Controls.Add(Me.lblUnit2)
        Me.Controls.Add(Me.lblUnit)
        Me.Controls.Add(Me.lblEnterHeight)
        Me.Controls.Add(Me.lblEnterWeight)
        Me.Controls.Add(Me.lstUnitSelection)
        Me.Controls.Add(Me.txtHeight)
        Me.Controls.Add(Me.txtWeight)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmBMI"
        Me.Text = "BMI Calculator - How Fat Are You?"
        CType(Me.picObese, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picOverWeight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picNormal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMeter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picUnderweight, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents txtWeight As TextBox
    Friend WithEvents txtHeight As TextBox
    Friend WithEvents lstUnitSelection As ListBox
    Friend WithEvents lblEnterWeight As Label
    Friend WithEvents lblEnterHeight As Label
    Friend WithEvents lblUnit As Label
    Friend WithEvents lblUnit2 As Label
    Friend WithEvents lblConversionSelection As Label
    Friend WithEvents lblHeader As Label
    Friend WithEvents lblResults As Label
    Friend WithEvents picUnderweight As PictureBox
    Friend WithEvents picMeter As PictureBox
    Friend WithEvents picNormal As PictureBox
    Friend WithEvents picOverWeight As PictureBox
    Friend WithEvents picObese As PictureBox
End Class
