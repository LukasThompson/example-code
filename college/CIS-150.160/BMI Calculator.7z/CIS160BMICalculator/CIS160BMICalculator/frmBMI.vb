﻿' Program Name: BMI Calculator
' Author: Lukas Thompson
' Date: 10-07-2016
' Purpose: This Windows application allows a user to select from either the imperial or metric system, enter their weight and height and press calculate. 
' The Body Fat Percentage is then displayed to the user.

Option Strict On
'Enable option strict
' With this option enabled, you can't accidentally convert one data type to another that is less precise (e.g. from an Integer to a Byte). -StackOverflow Definition

Public Class frmBMI
    'Constants and Global Variables will be declared in this section
    Dim decWeight As Decimal = 0D
    Dim decHeight As Decimal = 0D
    Dim decImperialBMI As Decimal = 0D
    Dim decMetricBMI As Decimal = 0D
    Dim intConversionSelection As Integer = -1





    Private Sub frmBMI_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Threading.Thread.Sleep(3000)
        ' Set sleep timer on our splash screen to 3 seconds
    End Sub

    Private Sub lstUnitSelection_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstUnitSelection.SelectedIndexChanged
        intConversionSelection = lstUnitSelection.SelectedIndex
        Select Case intConversionSelection
            Case 0
                ' User Selected Metric
                btnCalculate.Enabled = True
                ' Gives user the ability to use the calculate button
            Case 1
                ' User Selected Imperial
                btnCalculate.Enabled = True
                ' Gives user the ability to use the calculate button
        End Select
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        If intConversionSelection = 0 Then
            MetricBMI()
            DisplayInfo()
        ElseIf intConversionSelection = 1 Then
            ImperialBMI()
            DisplayInfo()
        Else
            MsgBox("Please enter numbers",, "Error")
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        Clear()
    End Sub



    ' Sub procedures and functions go below.

    Private Function MetricBMI() As Decimal
        Try
            decWeight = Convert.ToDecimal(txtWeight.Text)
            decHeight = Convert.ToDecimal(txtHeight.Text)
            decMetricBMI = (decWeight / (decHeight * decHeight))
        Catch ex As Exception
            MsgBox("Please enter numbers only!",, "Error")
        End Try
        Return decMetricBMI
    End Function


    Private Function ImperialBMI() As Decimal
        Try
            decWeight = Convert.ToDecimal(txtWeight.Text)
            decHeight = Convert.ToDecimal(txtHeight.Text)
            decImperialBMI = (decWeight / (decHeight * decHeight)) * 703
        Catch ex As Exception
            MsgBox("Please enter numbers only!",, "Error")
        End Try
        Return decImperialBMI
    End Function

    Private Sub DisplayInfo()
        If intConversionSelection = 0 Then
            ' User Selected Metric
            Select Case decMetricBMI
                Case > 30D
                    picUnderweight.Visible = False
                    picNormal.Visible = False
                    picOverWeight.Visible = False
                    picObese.Visible = True
                    lblResults.Text = "You are at " & decMetricBMI.ToString("N2") & "% Body fat, you are Obese."
                Case > 25D
                    picUnderweight.Visible = False
                    picNormal.Visible = False
                    picObese.Visible = False
                    picOverWeight.Visible = True
                    lblResults.Text = "You are at " & decMetricBMI.ToString("N2") & "% Body fat, you are Over Weight."
                Case > 18.5D
                    picUnderweight.Visible = False
                    picOverWeight.Visible = False
                    picObese.Visible = False
                    picNormal.Visible = True
                    lblResults.Text = "You are at " & decMetricBMI.ToString("N2") & "% Body fat, you are Normal."
                Case < 18.5D
                    picNormal.Visible = False
                    picOverWeight.Visible = False
                    picObese.Visible = False
                    picUnderweight.Visible = True
                    lblResults.Text = "You are at " & decMetricBMI.ToString("N2") & "% Body fat, you are Under Weight."
            End Select
        ElseIf intConversionSelection = 1 Then
            ' User Selected Imperial
            Select Case decImperialBMI
                Case > 30D
                    picUnderweight.Visible = False
                    picNormal.Visible = False
                    picOverWeight.Visible = False
                    picObese.Visible = True
                    lblResults.Text = "You are at " & decImperialBMI.ToString("N2") & "% Body fat, you are Obese."
                Case > 25D
                    picUnderweight.Visible = False
                    picNormal.Visible = False
                    picObese.Visible = False
                    picOverWeight.Visible = True
                    lblResults.Text = "You are at " & decImperialBMI.ToString("N2") & "% Body fat, you are Over Weight."
                Case > 18.5D
                    picUnderweight.Visible = False
                    picOverWeight.Visible = False
                    picObese.Visible = False
                    picNormal.Visible = True
                    lblResults.Text = "You are at " & decImperialBMI.ToString("N2") & "% Body fat, you are Normal."
                Case < 18.5D
                    picNormal.Visible = False
                    picOverWeight.Visible = False
                    picObese.Visible = False
                    picUnderweight.Visible = True
                    lblResults.Text = "You are at " & decImperialBMI.ToString("N2") & "% Body fat, you are Under Weight."
            End Select
        End If
    End Sub
    ' For showing the images, would I go about using just one picBox something like:
    '                     picResult.Image = "ImageName" 
    '  I was thinking it would be easier to just change one line rather than enabling and disabling every picture
    ' Thanks

    Private Sub Clear()
        txtHeight.Text = ""
        txtWeight.Text = ""
        lblResults.Text = ""
        lstUnitSelection.ClearSelected()
        picUnderweight.Visible = False
        picNormal.Visible = False
        picOverWeight.Visible = False
        picObese.Visible = False
        btnCalculate.Enabled = False
        txtWeight.Focus()
    End Sub
End Class
