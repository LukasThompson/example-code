﻿Option Strict On
Public Class frmCollegeMajors
    Dim decTotalStudents As Decimal
    Dim intCount As Integer



    Private Sub CollegeMajorsBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles CollegeMajorsBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.CollegeMajorsBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.CollegeDataSet)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CollegeDataSet.CollegeMajors' table. You can move, or remove it, as needed.
        Me.CollegeMajorsTableAdapter.Fill(Me.CollegeDataSet.CollegeMajors)
        Dim strConn As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\College.accdb"
        Dim strSQL As String = "SELECT Sum(CollegeMajors.[Number in Degree]) FROM CollegeMajors;"
        Dim odcConn As New OleDb.OleDbConnection(strConn)
        Dim odcCommand As New OleDb.OleDbCommand(strSQL)
        odcCommand.Connection = odcConn
        odcConn.Open()
        Dim objTotal As Object = odcCommand.ExecuteScalar()
        odcConn.Close()
        Try
            decTotalStudents = Convert.ToDecimal(objTotal)
        Catch ex As Exception
            MsgBox("No Majors",, "Critical Error")
        End Try

    End Sub

    Private Sub DegreeComboBox_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDegree.SelectedIndexChanged
        Try
            Dim decStudents As Decimal = Convert.ToDecimal(txtNumberInDegree.Text)
            Dim decPercent As Decimal = 0D
            Dim decWorkingNumber As Decimal = 0D
            decWorkingNumber = decStudents * 100
            decPercent = decWorkingNumber / decTotalStudents
            lblPercent.Text = decPercent.ToString("N2")
        Catch ex As Exception
            MsgBox("Invalid Input",, "Something Went Wrong!")
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnTotalStudents.Click
        lblEnrolledStudents.Text = "Currently we have " & decTotalStudents & " enrolled in our courses!"

    End Sub
End Class
