﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCollegeMajors
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim lblNID As System.Windows.Forms.Label
        Dim lblDegree As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCollegeMajors))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.CollegeDataSet = New CIS160CollegeMajors.CollegeDataSet()
        Me.CollegeMajorsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CollegeMajorsTableAdapter = New CIS160CollegeMajors.CollegeDataSetTableAdapters.CollegeMajorsTableAdapter()
        Me.TableAdapterManager = New CIS160CollegeMajors.CollegeDataSetTableAdapters.TableAdapterManager()
        Me.CollegeMajorsBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.CollegeMajorsBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.txtNumberInDegree = New System.Windows.Forms.TextBox()
        Me.cboDegree = New System.Windows.Forms.ComboBox()
        Me.lblPercent = New System.Windows.Forms.Label()
        Me.btnTotalStudents = New System.Windows.Forms.Button()
        Me.lblPID = New System.Windows.Forms.Label()
        Me.lblEnrolledStudents = New System.Windows.Forms.Label()
        lblNID = New System.Windows.Forms.Label()
        lblDegree = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CollegeDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CollegeMajorsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CollegeMajorsBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.CollegeMajorsBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblNID
        '
        lblNID.AutoSize = True
        lblNID.Location = New System.Drawing.Point(191, 243)
        lblNID.Name = "lblNID"
        lblNID.Size = New System.Drawing.Size(96, 13)
        lblNID.TabIndex = 7
        lblNID.Text = "Number in Degree:"
        '
        'lblDegree
        '
        lblDegree.AutoSize = True
        lblDegree.Location = New System.Drawing.Point(242, 181)
        lblDegree.Name = "lblDegree"
        lblDegree.Size = New System.Drawing.Size(45, 13)
        lblDegree.TabIndex = 9
        lblDegree.Text = "Degree:"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.CIS160CollegeMajors.My.Resources.Resources.selecting_college_major
        Me.PictureBox1.Location = New System.Drawing.Point(0, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(604, 166)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'CollegeDataSet
        '
        Me.CollegeDataSet.DataSetName = "CollegeDataSet"
        Me.CollegeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CollegeMajorsBindingSource
        '
        Me.CollegeMajorsBindingSource.DataMember = "CollegeMajors"
        Me.CollegeMajorsBindingSource.DataSource = Me.CollegeDataSet
        '
        'CollegeMajorsTableAdapter
        '
        Me.CollegeMajorsTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CollegeMajorsTableAdapter = Me.CollegeMajorsTableAdapter
        Me.TableAdapterManager.UpdateOrder = CIS160CollegeMajors.CollegeDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'CollegeMajorsBindingNavigator
        '
        Me.CollegeMajorsBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.CollegeMajorsBindingNavigator.BindingSource = Me.CollegeMajorsBindingSource
        Me.CollegeMajorsBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.CollegeMajorsBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.CollegeMajorsBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.CollegeMajorsBindingNavigatorSaveItem})
        Me.CollegeMajorsBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.CollegeMajorsBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.CollegeMajorsBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.CollegeMajorsBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.CollegeMajorsBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.CollegeMajorsBindingNavigator.Name = "CollegeMajorsBindingNavigator"
        Me.CollegeMajorsBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.CollegeMajorsBindingNavigator.Size = New System.Drawing.Size(604, 25)
        Me.CollegeMajorsBindingNavigator.TabIndex = 4
        Me.CollegeMajorsBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'CollegeMajorsBindingNavigatorSaveItem
        '
        Me.CollegeMajorsBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CollegeMajorsBindingNavigatorSaveItem.Image = CType(resources.GetObject("CollegeMajorsBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.CollegeMajorsBindingNavigatorSaveItem.Name = "CollegeMajorsBindingNavigatorSaveItem"
        Me.CollegeMajorsBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.CollegeMajorsBindingNavigatorSaveItem.Text = "Save Data"
        '
        'txtNumberInDegree
        '
        Me.txtNumberInDegree.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CollegeMajorsBindingSource, "Number in Degree", True))
        Me.txtNumberInDegree.Location = New System.Drawing.Point(293, 240)
        Me.txtNumberInDegree.Name = "txtNumberInDegree"
        Me.txtNumberInDegree.Size = New System.Drawing.Size(100, 20)
        Me.txtNumberInDegree.TabIndex = 8
        '
        'cboDegree
        '
        Me.cboDegree.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CollegeMajorsBindingSource, "Degree", True))
        Me.cboDegree.DataSource = Me.CollegeMajorsBindingSource
        Me.cboDegree.DisplayMember = "Degree"
        Me.cboDegree.FormattingEnabled = True
        Me.cboDegree.Location = New System.Drawing.Point(293, 178)
        Me.cboDegree.Name = "cboDegree"
        Me.cboDegree.Size = New System.Drawing.Size(121, 21)
        Me.cboDegree.TabIndex = 10
        Me.cboDegree.ValueMember = "Degree"
        '
        'lblPercent
        '
        Me.lblPercent.AutoSize = True
        Me.lblPercent.Location = New System.Drawing.Point(290, 212)
        Me.lblPercent.Name = "lblPercent"
        Me.lblPercent.Size = New System.Drawing.Size(0, 13)
        Me.lblPercent.TabIndex = 11
        '
        'btnTotalStudents
        '
        Me.btnTotalStudents.Location = New System.Drawing.Point(238, 266)
        Me.btnTotalStudents.Name = "btnTotalStudents"
        Me.btnTotalStudents.Size = New System.Drawing.Size(128, 23)
        Me.btnTotalStudents.TabIndex = 12
        Me.btnTotalStudents.Text = "Total Students"
        Me.btnTotalStudents.UseVisualStyleBackColor = True
        '
        'lblPID
        '
        Me.lblPID.AutoSize = True
        Me.lblPID.Location = New System.Drawing.Point(191, 212)
        Me.lblPID.Name = "lblPID"
        Me.lblPID.Size = New System.Drawing.Size(96, 13)
        Me.lblPID.TabIndex = 13
        Me.lblPID.Text = "Percent in Degree:"
        '
        'lblEnrolledStudents
        '
        Me.lblEnrolledStudents.AutoSize = True
        Me.lblEnrolledStudents.Location = New System.Drawing.Point(191, 306)
        Me.lblEnrolledStudents.Name = "lblEnrolledStudents"
        Me.lblEnrolledStudents.Size = New System.Drawing.Size(0, 13)
        Me.lblEnrolledStudents.TabIndex = 14
        '
        'frmCollegeMajors
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(604, 362)
        Me.Controls.Add(Me.lblEnrolledStudents)
        Me.Controls.Add(Me.lblPID)
        Me.Controls.Add(Me.btnTotalStudents)
        Me.Controls.Add(Me.lblPercent)
        Me.Controls.Add(lblDegree)
        Me.Controls.Add(Me.cboDegree)
        Me.Controls.Add(lblNID)
        Me.Controls.Add(Me.txtNumberInDegree)
        Me.Controls.Add(Me.CollegeMajorsBindingNavigator)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmCollegeMajors"
        Me.Text = "College Majors"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CollegeDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CollegeMajorsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CollegeMajorsBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.CollegeMajorsBindingNavigator.ResumeLayout(False)
        Me.CollegeMajorsBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents CollegeDataSet As CollegeDataSet
    Friend WithEvents CollegeMajorsBindingSource As BindingSource
    Friend WithEvents CollegeMajorsTableAdapter As CollegeDataSetTableAdapters.CollegeMajorsTableAdapter
    Friend WithEvents TableAdapterManager As CollegeDataSetTableAdapters.TableAdapterManager
    Friend WithEvents CollegeMajorsBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents CollegeMajorsBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents txtNumberInDegree As TextBox
    Friend WithEvents cboDegree As ComboBox
    Friend WithEvents lblPercent As Label
    Friend WithEvents btnTotalStudents As Button
    Friend WithEvents lblPID As Label
    Friend WithEvents lblEnrolledStudents As Label
End Class
