﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGuitarSale
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnClassical = New System.Windows.Forms.Button()
        Me.btnElectric = New System.Windows.Forms.Button()
        Me.btnSteel = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.chkBuyMe = New System.Windows.Forms.CheckBox()
        Me.btnPurchase = New System.Windows.Forms.Button()
        Me.lblConfirmation = New System.Windows.Forms.Label()
        Me.lblSale = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(50, 92)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(236, 370)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'btnClassical
        '
        Me.btnClassical.Location = New System.Drawing.Point(318, 92)
        Me.btnClassical.Name = "btnClassical"
        Me.btnClassical.Size = New System.Drawing.Size(125, 23)
        Me.btnClassical.TabIndex = 1
        Me.btnClassical.Text = "Classical Guitar"
        Me.btnClassical.UseVisualStyleBackColor = True
        '
        'btnElectric
        '
        Me.btnElectric.Location = New System.Drawing.Point(318, 218)
        Me.btnElectric.Name = "btnElectric"
        Me.btnElectric.Size = New System.Drawing.Size(125, 23)
        Me.btnElectric.TabIndex = 2
        Me.btnElectric.Text = "Electric Guitar"
        Me.btnElectric.UseVisualStyleBackColor = True
        '
        'btnSteel
        '
        Me.btnSteel.Location = New System.Drawing.Point(318, 337)
        Me.btnSteel.Name = "btnSteel"
        Me.btnSteel.Size = New System.Drawing.Size(125, 23)
        Me.btnSteel.TabIndex = 3
        Me.btnSteel.Text = "Steel String Guitar"
        Me.btnSteel.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(448, 439)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 4
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'chkBuyMe
        '
        Me.chkBuyMe.AutoSize = True
        Me.chkBuyMe.Location = New System.Drawing.Point(110, 468)
        Me.chkBuyMe.Name = "chkBuyMe"
        Me.chkBuyMe.Size = New System.Drawing.Size(104, 17)
        Me.chkBuyMe.TabIndex = 5
        Me.chkBuyMe.Text = "Buy This Guitar?"
        Me.chkBuyMe.UseVisualStyleBackColor = True
        '
        'btnPurchase
        '
        Me.btnPurchase.Location = New System.Drawing.Point(318, 439)
        Me.btnPurchase.Name = "btnPurchase"
        Me.btnPurchase.Size = New System.Drawing.Size(75, 23)
        Me.btnPurchase.TabIndex = 6
        Me.btnPurchase.Text = "Purchase"
        Me.btnPurchase.UseVisualStyleBackColor = True
        '
        'lblConfirmation
        '
        Me.lblConfirmation.AutoSize = True
        Me.lblConfirmation.Location = New System.Drawing.Point(315, 475)
        Me.lblConfirmation.Name = "lblConfirmation"
        Me.lblConfirmation.Size = New System.Drawing.Size(88, 13)
        Me.lblConfirmation.TabIndex = 7
        Me.lblConfirmation.Text = "Enjoy your guitar!"
        '
        'lblSale
        '
        Me.lblSale.AutoSize = True
        Me.lblSale.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSale.Location = New System.Drawing.Point(150, 34)
        Me.lblSale.Name = "lblSale"
        Me.lblSale.Size = New System.Drawing.Size(234, 23)
        Me.lblSale.TabIndex = 8
        Me.lblSale.Text = "This Weeks Sale Items!"
        '
        'frmGuitarSale
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(535, 492)
        Me.Controls.Add(Me.lblSale)
        Me.Controls.Add(Me.lblConfirmation)
        Me.Controls.Add(Me.btnPurchase)
        Me.Controls.Add(Me.chkBuyMe)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnSteel)
        Me.Controls.Add(Me.btnElectric)
        Me.Controls.Add(Me.btnClassical)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmGuitarSale"
        Me.Text = "Guitar Sale"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnClassical As Button
    Friend WithEvents btnElectric As Button
    Friend WithEvents btnSteel As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents chkBuyMe As CheckBox
    Friend WithEvents btnPurchase As Button
    Friend WithEvents lblConfirmation As Label
    Friend WithEvents lblSale As Label
End Class
