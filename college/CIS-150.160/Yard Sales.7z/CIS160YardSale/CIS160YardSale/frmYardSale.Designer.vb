﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmYardSale
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim lblID As System.Windows.Forms.Label
        Dim lblOwner As System.Windows.Forms.Label
        Dim lblLocation As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmYardSale))
        Me.lblHeader = New System.Windows.Forms.Label()
        Me.picYardSale = New System.Windows.Forms.PictureBox()
        Me.SalesDataSet = New CIS160YardSale.SalesDataSet()
        Me.YardSaleBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.YardSaleTableAdapter = New CIS160YardSale.SalesDataSetTableAdapters.YardSaleTableAdapter()
        Me.TableAdapterManager = New CIS160YardSale.SalesDataSetTableAdapters.TableAdapterManager()
        Me.YardSaleBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.YardSaleBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.txtOwner = New System.Windows.Forms.TextBox()
        Me.txtLocation = New System.Windows.Forms.TextBox()
        lblID = New System.Windows.Forms.Label()
        lblOwner = New System.Windows.Forms.Label()
        lblLocation = New System.Windows.Forms.Label()
        CType(Me.picYardSale, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SalesDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.YardSaleBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.YardSaleBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.YardSaleBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblID
        '
        lblID.AutoSize = True
        lblID.Font = New System.Drawing.Font("Modern No. 20", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblID.Location = New System.Drawing.Point(34, 200)
        lblID.Name = "lblID"
        lblID.Size = New System.Drawing.Size(162, 25)
        lblID.TabIndex = 3
        lblID.Text = "Yard Sale ID:"
        '
        'lblOwner
        '
        lblOwner.AutoSize = True
        lblOwner.Font = New System.Drawing.Font("Modern No. 20", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblOwner.Location = New System.Drawing.Point(64, 289)
        lblOwner.Name = "lblOwner"
        lblOwner.Size = New System.Drawing.Size(201, 25)
        lblOwner.TabIndex = 5
        lblOwner.Text = "Yard Sale Owner:"
        '
        'lblLocation
        '
        lblLocation.AutoSize = True
        lblLocation.Font = New System.Drawing.Font("Modern No. 20", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblLocation.Location = New System.Drawing.Point(108, 394)
        lblLocation.Name = "lblLocation"
        lblLocation.Size = New System.Drawing.Size(113, 25)
        lblLocation.TabIndex = 7
        lblLocation.Text = "Location:"
        '
        'lblHeader
        '
        Me.lblHeader.AutoSize = True
        Me.lblHeader.Font = New System.Drawing.Font("Californian FB", 72.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.ForeColor = System.Drawing.Color.Red
        Me.lblHeader.Location = New System.Drawing.Point(27, 45)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(817, 110)
        Me.lblHeader.TabIndex = 0
        Me.lblHeader.Text = "Saturday Yard Sales"
        '
        'picYardSale
        '
        Me.picYardSale.Image = Global.CIS160YardSale.My.Resources.Resources.Yard
        Me.picYardSale.Location = New System.Drawing.Point(388, 174)
        Me.picYardSale.Name = "picYardSale"
        Me.picYardSale.Size = New System.Drawing.Size(447, 318)
        Me.picYardSale.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picYardSale.TabIndex = 1
        Me.picYardSale.TabStop = False
        '
        'SalesDataSet
        '
        Me.SalesDataSet.DataSetName = "SalesDataSet"
        Me.SalesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'YardSaleBindingSource
        '
        Me.YardSaleBindingSource.DataMember = "YardSale"
        Me.YardSaleBindingSource.DataSource = Me.SalesDataSet
        '
        'YardSaleTableAdapter
        '
        Me.YardSaleTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.UpdateOrder = CIS160YardSale.SalesDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.YardSaleTableAdapter = Me.YardSaleTableAdapter
        '
        'YardSaleBindingNavigator
        '
        Me.YardSaleBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.YardSaleBindingNavigator.BindingSource = Me.YardSaleBindingSource
        Me.YardSaleBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.YardSaleBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.YardSaleBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.YardSaleBindingNavigatorSaveItem})
        Me.YardSaleBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.YardSaleBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.YardSaleBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.YardSaleBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.YardSaleBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.YardSaleBindingNavigator.Name = "YardSaleBindingNavigator"
        Me.YardSaleBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.YardSaleBindingNavigator.Size = New System.Drawing.Size(869, 25)
        Me.YardSaleBindingNavigator.TabIndex = 2
        Me.YardSaleBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'YardSaleBindingNavigatorSaveItem
        '
        Me.YardSaleBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.YardSaleBindingNavigatorSaveItem.Image = CType(resources.GetObject("YardSaleBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.YardSaleBindingNavigatorSaveItem.Name = "YardSaleBindingNavigatorSaveItem"
        Me.YardSaleBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.YardSaleBindingNavigatorSaveItem.Text = "Save Data"
        '
        'txtID
        '
        Me.txtID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.YardSaleBindingSource, "Yard Sale ID", True))
        Me.txtID.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtID.Location = New System.Drawing.Point(227, 198)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(100, 30)
        Me.txtID.TabIndex = 4
        '
        'txtOwner
        '
        Me.txtOwner.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.YardSaleBindingSource, "Yard Sale Owner", True))
        Me.txtOwner.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOwner.Location = New System.Drawing.Point(57, 335)
        Me.txtOwner.Name = "txtOwner"
        Me.txtOwner.Size = New System.Drawing.Size(215, 30)
        Me.txtOwner.TabIndex = 6
        '
        'txtLocation
        '
        Me.txtLocation.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.YardSaleBindingSource, "Location", True))
        Me.txtLocation.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLocation.Location = New System.Drawing.Point(57, 440)
        Me.txtLocation.Name = "txtLocation"
        Me.txtLocation.Size = New System.Drawing.Size(215, 30)
        Me.txtLocation.TabIndex = 8
        '
        'frmYardSale
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(869, 513)
        Me.Controls.Add(lblLocation)
        Me.Controls.Add(Me.txtLocation)
        Me.Controls.Add(lblOwner)
        Me.Controls.Add(Me.txtOwner)
        Me.Controls.Add(lblID)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(Me.YardSaleBindingNavigator)
        Me.Controls.Add(Me.picYardSale)
        Me.Controls.Add(Me.lblHeader)
        Me.Name = "frmYardSale"
        Me.Text = "Weekly Yard Sales"
        CType(Me.picYardSale, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SalesDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.YardSaleBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.YardSaleBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.YardSaleBindingNavigator.ResumeLayout(False)
        Me.YardSaleBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblHeader As Label
    Friend WithEvents picYardSale As PictureBox
    Friend WithEvents SalesDataSet As SalesDataSet
    Friend WithEvents YardSaleBindingSource As BindingSource
    Friend WithEvents YardSaleTableAdapter As SalesDataSetTableAdapters.YardSaleTableAdapter
    Friend WithEvents TableAdapterManager As SalesDataSetTableAdapters.TableAdapterManager
    Friend WithEvents YardSaleBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents YardSaleBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents txtID As TextBox
    Friend WithEvents txtOwner As TextBox
    Friend WithEvents txtLocation As TextBox
End Class
