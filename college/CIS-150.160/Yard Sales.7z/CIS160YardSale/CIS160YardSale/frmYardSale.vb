﻿Public Class frmYardSale
    Private Sub YardSaleBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles YardSaleBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.YardSaleBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.SalesDataSet)

    End Sub

    Private Sub frmYardSale_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'SalesDataSet.YardSale' table. You can move, or remove it, as needed.
        Me.YardSaleTableAdapter.Fill(Me.SalesDataSet.YardSale)
        Dim strPath As String = "Provider=Microsoft.ACE.OLEDB.12.0;" & "Data Source=e:\Sales.accdb"
        ' I wasn't really sure what to do in this project... All it wants is for it to save and delete. The only requirement is to have the data on th E drive
        ' I was assuming change it in the App.config, but since it already says |Data Directory| then it would be suitable.
        ' I figured since the save and delete is taken care of from the Navigation Bar that I just needed really to declare my path
        ' I thought that the above line would demonstrate that we are accessing the "E" drive but there is actually no need for it
        ' There wasn't anything that said anything about sorting or anything so really it just wants you to show that you know how to connect the database?
        ' Also I realized at the end of my project, I probably should have copied the database file over to my project folder before connecting. I made sure
        ' to fix that in the next assignment. 
    End Sub
End Class
