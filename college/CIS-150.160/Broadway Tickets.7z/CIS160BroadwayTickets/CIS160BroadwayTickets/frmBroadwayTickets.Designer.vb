﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBroadwayTickets
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBroadwayTickets))
        Me.lblHeader = New System.Windows.Forms.Label()
        Me.cboPlaySelection = New System.Windows.Forms.ComboBox()
        Me.lblNumberOfTickets = New System.Windows.Forms.Label()
        Me.txtNumberOfTickets = New System.Windows.Forms.TextBox()
        Me.pnlRadioButtons = New System.Windows.Forms.Panel()
        Me.radMezzanine = New System.Windows.Forms.RadioButton()
        Me.radOrchestra = New System.Windows.Forms.RadioButton()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.lblSubTotalText = New System.Windows.Forms.Label()
        Me.lblTaxText = New System.Windows.Forms.Label()
        Me.lblTotalText = New System.Windows.Forms.Label()
        Me.pnlInformationText = New System.Windows.Forms.Panel()
        Me.pnlTotalAmounts = New System.Windows.Forms.Panel()
        Me.lblSubTotalAmount = New System.Windows.Forms.Label()
        Me.lblTaxAmount = New System.Windows.Forms.Label()
        Me.lblFinalTotalAmount = New System.Windows.Forms.Label()
        Me.pnlSelectionInformation = New System.Windows.Forms.Panel()
        Me.picUsher = New System.Windows.Forms.PictureBox()
        Me.pnlRadioButtons.SuspendLayout()
        Me.pnlInformationText.SuspendLayout()
        Me.pnlTotalAmounts.SuspendLayout()
        Me.pnlSelectionInformation.SuspendLayout()
        CType(Me.picUsher, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblHeader
        '
        Me.lblHeader.AutoSize = True
        Me.lblHeader.Font = New System.Drawing.Font("Modern No. 20", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.ForeColor = System.Drawing.Color.White
        Me.lblHeader.Location = New System.Drawing.Point(351, 9)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(290, 29)
        Me.lblHeader.TabIndex = 0
        Me.lblHeader.Text = "Broadway Play Tickets"
        '
        'cboPlaySelection
        '
        Me.cboPlaySelection.BackColor = System.Drawing.Color.White
        Me.cboPlaySelection.Font = New System.Drawing.Font("Lucida Sans", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboPlaySelection.FormattingEnabled = True
        Me.cboPlaySelection.Items.AddRange(New Object() {"Lion King", "Wicked", "Phantom of the Opera"})
        Me.cboPlaySelection.Location = New System.Drawing.Point(38, 15)
        Me.cboPlaySelection.Name = "cboPlaySelection"
        Me.cboPlaySelection.Size = New System.Drawing.Size(302, 26)
        Me.cboPlaySelection.TabIndex = 2
        Me.cboPlaySelection.Text = "Please Select Your Play"
        '
        'lblNumberOfTickets
        '
        Me.lblNumberOfTickets.AutoSize = True
        Me.lblNumberOfTickets.Font = New System.Drawing.Font("Lucida Sans", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNumberOfTickets.ForeColor = System.Drawing.Color.White
        Me.lblNumberOfTickets.Location = New System.Drawing.Point(93, 68)
        Me.lblNumberOfTickets.Name = "lblNumberOfTickets"
        Me.lblNumberOfTickets.Size = New System.Drawing.Size(193, 18)
        Me.lblNumberOfTickets.TabIndex = 3
        Me.lblNumberOfTickets.Text = "Enter Number of Tickets:"
        Me.lblNumberOfTickets.Visible = False
        '
        'txtNumberOfTickets
        '
        Me.txtNumberOfTickets.Font = New System.Drawing.Font("Lucida Sans", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNumberOfTickets.Location = New System.Drawing.Point(160, 97)
        Me.txtNumberOfTickets.Name = "txtNumberOfTickets"
        Me.txtNumberOfTickets.Size = New System.Drawing.Size(59, 26)
        Me.txtNumberOfTickets.TabIndex = 4
        Me.txtNumberOfTickets.Visible = False
        '
        'pnlRadioButtons
        '
        Me.pnlRadioButtons.Controls.Add(Me.radMezzanine)
        Me.pnlRadioButtons.Controls.Add(Me.radOrchestra)
        Me.pnlRadioButtons.Location = New System.Drawing.Point(307, 216)
        Me.pnlRadioButtons.Name = "pnlRadioButtons"
        Me.pnlRadioButtons.Size = New System.Drawing.Size(186, 52)
        Me.pnlRadioButtons.TabIndex = 5
        Me.pnlRadioButtons.Visible = False
        '
        'radMezzanine
        '
        Me.radMezzanine.AutoSize = True
        Me.radMezzanine.Font = New System.Drawing.Font("Lucida Sans", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radMezzanine.ForeColor = System.Drawing.Color.White
        Me.radMezzanine.Location = New System.Drawing.Point(3, 27)
        Me.radMezzanine.Name = "radMezzanine"
        Me.radMezzanine.Size = New System.Drawing.Size(107, 22)
        Me.radMezzanine.TabIndex = 1
        Me.radMezzanine.TabStop = True
        Me.radMezzanine.Text = "Mezzanine"
        Me.radMezzanine.UseVisualStyleBackColor = True
        '
        'radOrchestra
        '
        Me.radOrchestra.AutoSize = True
        Me.radOrchestra.Font = New System.Drawing.Font("Lucida Sans", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radOrchestra.ForeColor = System.Drawing.Color.White
        Me.radOrchestra.Location = New System.Drawing.Point(3, 3)
        Me.radOrchestra.Name = "radOrchestra"
        Me.radOrchestra.Size = New System.Drawing.Size(97, 22)
        Me.radOrchestra.TabIndex = 0
        Me.radOrchestra.TabStop = True
        Me.radOrchestra.Text = "Orchestra"
        Me.radOrchestra.UseVisualStyleBackColor = True
        '
        'btnCalculate
        '
        Me.btnCalculate.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnCalculate.Font = New System.Drawing.Font("Lucida Sans", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculate.ForeColor = System.Drawing.Color.White
        Me.btnCalculate.Location = New System.Drawing.Point(541, 216)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(116, 52)
        Me.btnCalculate.TabIndex = 6
        Me.btnCalculate.Text = "Calculate" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Cost"
        Me.btnCalculate.UseVisualStyleBackColor = False
        Me.btnCalculate.Visible = False
        '
        'lblSubTotalText
        '
        Me.lblSubTotalText.AutoSize = True
        Me.lblSubTotalText.Font = New System.Drawing.Font("Lucida Sans", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubTotalText.ForeColor = System.Drawing.Color.White
        Me.lblSubTotalText.Location = New System.Drawing.Point(7, 11)
        Me.lblSubTotalText.Name = "lblSubTotalText"
        Me.lblSubTotalText.Size = New System.Drawing.Size(84, 18)
        Me.lblSubTotalText.TabIndex = 7
        Me.lblSubTotalText.Text = "Sub Total:"
        '
        'lblTaxText
        '
        Me.lblTaxText.AutoSize = True
        Me.lblTaxText.Font = New System.Drawing.Font("Lucida Sans", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTaxText.ForeColor = System.Drawing.Color.White
        Me.lblTaxText.Location = New System.Drawing.Point(7, 43)
        Me.lblTaxText.Name = "lblTaxText"
        Me.lblTaxText.Size = New System.Drawing.Size(40, 18)
        Me.lblTaxText.TabIndex = 8
        Me.lblTaxText.Text = "Tax:"
        '
        'lblTotalText
        '
        Me.lblTotalText.AutoSize = True
        Me.lblTotalText.Font = New System.Drawing.Font("Lucida Sans", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalText.ForeColor = System.Drawing.Color.White
        Me.lblTotalText.Location = New System.Drawing.Point(7, 75)
        Me.lblTotalText.Name = "lblTotalText"
        Me.lblTotalText.Size = New System.Drawing.Size(93, 18)
        Me.lblTotalText.TabIndex = 9
        Me.lblTotalText.Text = "Final Total:"
        '
        'pnlInformationText
        '
        Me.pnlInformationText.Controls.Add(Me.lblSubTotalText)
        Me.pnlInformationText.Controls.Add(Me.lblTaxText)
        Me.pnlInformationText.Controls.Add(Me.lblTotalText)
        Me.pnlInformationText.Location = New System.Drawing.Point(307, 286)
        Me.pnlInformationText.Name = "pnlInformationText"
        Me.pnlInformationText.Size = New System.Drawing.Size(200, 100)
        Me.pnlInformationText.TabIndex = 13
        Me.pnlInformationText.Visible = False
        '
        'pnlTotalAmounts
        '
        Me.pnlTotalAmounts.Controls.Add(Me.lblSubTotalAmount)
        Me.pnlTotalAmounts.Controls.Add(Me.lblTaxAmount)
        Me.pnlTotalAmounts.Controls.Add(Me.lblFinalTotalAmount)
        Me.pnlTotalAmounts.Location = New System.Drawing.Point(512, 286)
        Me.pnlTotalAmounts.Name = "pnlTotalAmounts"
        Me.pnlTotalAmounts.Size = New System.Drawing.Size(174, 100)
        Me.pnlTotalAmounts.TabIndex = 14
        Me.pnlTotalAmounts.Visible = False
        '
        'lblSubTotalAmount
        '
        Me.lblSubTotalAmount.AutoSize = True
        Me.lblSubTotalAmount.Font = New System.Drawing.Font("Lucida Sans", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubTotalAmount.ForeColor = System.Drawing.Color.White
        Me.lblSubTotalAmount.Location = New System.Drawing.Point(7, 11)
        Me.lblSubTotalAmount.Name = "lblSubTotalAmount"
        Me.lblSubTotalAmount.Size = New System.Drawing.Size(106, 18)
        Me.lblSubTotalAmount.TabIndex = 7
        Me.lblSubTotalAmount.Text = "$888,888.88"
        '
        'lblTaxAmount
        '
        Me.lblTaxAmount.AutoSize = True
        Me.lblTaxAmount.Font = New System.Drawing.Font("Lucida Sans", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTaxAmount.ForeColor = System.Drawing.Color.White
        Me.lblTaxAmount.Location = New System.Drawing.Point(7, 43)
        Me.lblTaxAmount.Name = "lblTaxAmount"
        Me.lblTaxAmount.Size = New System.Drawing.Size(96, 18)
        Me.lblTaxAmount.TabIndex = 8
        Me.lblTaxAmount.Text = "$88,888.88"
        '
        'lblFinalTotalAmount
        '
        Me.lblFinalTotalAmount.AutoSize = True
        Me.lblFinalTotalAmount.Font = New System.Drawing.Font("Lucida Sans", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFinalTotalAmount.ForeColor = System.Drawing.Color.White
        Me.lblFinalTotalAmount.Location = New System.Drawing.Point(7, 75)
        Me.lblFinalTotalAmount.Name = "lblFinalTotalAmount"
        Me.lblFinalTotalAmount.Size = New System.Drawing.Size(140, 18)
        Me.lblFinalTotalAmount.TabIndex = 9
        Me.lblFinalTotalAmount.Text = "$888,888,888.88"
        '
        'pnlSelectionInformation
        '
        Me.pnlSelectionInformation.Controls.Add(Me.cboPlaySelection)
        Me.pnlSelectionInformation.Controls.Add(Me.lblNumberOfTickets)
        Me.pnlSelectionInformation.Controls.Add(Me.txtNumberOfTickets)
        Me.pnlSelectionInformation.Location = New System.Drawing.Point(307, 56)
        Me.pnlSelectionInformation.Name = "pnlSelectionInformation"
        Me.pnlSelectionInformation.Size = New System.Drawing.Size(379, 142)
        Me.pnlSelectionInformation.TabIndex = 15
        '
        'picUsher
        '
        Me.picUsher.Image = Global.CIS160BroadwayTickets.My.Resources.Resources.Broadway2
        Me.picUsher.Location = New System.Drawing.Point(12, 36)
        Me.picUsher.Name = "picUsher"
        Me.picUsher.Size = New System.Drawing.Size(289, 162)
        Me.picUsher.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picUsher.TabIndex = 1
        Me.picUsher.TabStop = False
        '
        'frmBroadwayTickets
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(698, 397)
        Me.Controls.Add(Me.pnlSelectionInformation)
        Me.Controls.Add(Me.pnlTotalAmounts)
        Me.Controls.Add(Me.pnlInformationText)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.pnlRadioButtons)
        Me.Controls.Add(Me.picUsher)
        Me.Controls.Add(Me.lblHeader)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmBroadwayTickets"
        Me.Text = "Broadway Play Tickets"
        Me.pnlRadioButtons.ResumeLayout(False)
        Me.pnlRadioButtons.PerformLayout()
        Me.pnlInformationText.ResumeLayout(False)
        Me.pnlInformationText.PerformLayout()
        Me.pnlTotalAmounts.ResumeLayout(False)
        Me.pnlTotalAmounts.PerformLayout()
        Me.pnlSelectionInformation.ResumeLayout(False)
        Me.pnlSelectionInformation.PerformLayout()
        CType(Me.picUsher, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblHeader As Label
    Friend WithEvents picUsher As PictureBox
    Friend WithEvents cboPlaySelection As ComboBox
    Friend WithEvents lblNumberOfTickets As Label
    Friend WithEvents txtNumberOfTickets As TextBox
    Friend WithEvents pnlRadioButtons As Panel
    Friend WithEvents radMezzanine As RadioButton
    Friend WithEvents radOrchestra As RadioButton
    Friend WithEvents btnCalculate As Button
    Friend WithEvents lblSubTotalText As Label
    Friend WithEvents lblTaxText As Label
    Friend WithEvents lblTotalText As Label
    Friend WithEvents pnlInformationText As Panel
    Friend WithEvents pnlTotalAmounts As Panel
    Friend WithEvents lblSubTotalAmount As Label
    Friend WithEvents lblTaxAmount As Label
    Friend WithEvents lblFinalTotalAmount As Label
    Friend WithEvents pnlSelectionInformation As Panel
End Class
