﻿' Program Name: Broadway Ticket Selection Application
' Author: Lukas Thompson
' Date: 10-07-2016
' Purpose: This Windows application allows a user to select various Broadway plays, seating locations, and the number of tickets. 
' The total cost With tax Is computed And displayed To the user Of the application. 

Option Strict On
' Enable option strict
' With this option enabled, you can't accidentally convert one data type to another that is less precise (e.g. from an Integer to a Byte). -StackOverflow Definition


Public Class frmBroadwayTickets

    ' Declare the constants and variables we will need in order to execute the program
    Dim _cdecTax As Decimal = 0.12D
    Dim decSubTotal As Decimal = 0D
    Dim decTotal As Decimal = 0D
    Dim intNumberOfTickets As Integer = 0
    Dim decTaxAmount As Decimal = 0D
    Dim decPricePerTicket As Decimal = 0D
    Dim intPlayChoice As Integer = -1

    ' On Form Load
    Private Sub frmBroadwayTickets_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Start the program with a splash screen, set the timer to 5 seconds 
        Threading.Thread.Sleep(5000)
    End Sub

    'On Combo Select
    Private Sub cboPlaySelection_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboPlaySelection.SelectedIndexChanged
        intPlayChoice = cboPlaySelection.SelectedIndex
        Select Case intPlayChoice
            Case 0
                'User selected Lion King as Play Choice
                LionKing()
            Case 1
                'User selected Wicked as Play Choice
                Wicked()
            Case 2
                'User selected Phantom of the Opera as Play Choice
                PhantomOfTheOpera()
        End Select
    End Sub

    'On Button Click/Press
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        ValidateTicketNumbers()
        CheckRadio()

    End Sub






    ' Functions Below

    ' One function for EACH play
    Private Sub LionKing()
        ' The user selected the Lion King Play Choice
        lblNumberOfTickets.Visible = True
        txtNumberOfTickets.Visible = True
        ' Set ticket label visible
        pnlRadioButtons.Visible = True
        ' Set radio buttons visible
        btnCalculate.Visible = True
        ' Set button visible

    End Sub

    Private Sub Wicked()
        ' The user selected the Wicked Play Choice
        lblNumberOfTickets.Visible = True
        txtNumberOfTickets.Visible = True
        ' Set ticket label visible
        pnlRadioButtons.Visible = True
        ' Set radio buttons visible
        btnCalculate.Visible = True
        ' Set button visible

    End Sub

    Private Sub PhantomOfTheOpera()
        ' The user selected the Phantom of the Opera Play Choice
        lblNumberOfTickets.Visible = True
        txtNumberOfTickets.Visible = True
        ' Set ticket label visible
        pnlRadioButtons.Visible = True
        ' Set radio buttons visible
        btnCalculate.Visible = True
        ' Set button visible

    End Sub

    Private Sub ValidateTicketNumbers()
        Try
            intNumberOfTickets = Convert.ToInt32(txtNumberOfTickets.Text)
        Catch ex As Exception
            MsgBox("Please Enter a Valid Number",, "Error")
        End Try
    End Sub

    Private Sub CheckRadio()
        intPlayChoice = cboPlaySelection.SelectedIndex
        Select Case intPlayChoice
            Case 0
                'User selected Lion King
                If radOrchestra.Checked Then
                    decPricePerTicket = 135D
                    CalculateSubTotal()
                    TaxCalculation()
                    TotalCost()
                    DisplayAnswers()
                ElseIf radMezzanine.Checked Then
                    decPricePerTicket = 95D
                    CalculateSubTotal()
                    TaxCalculation()
                    TotalCost()
                    DisplayAnswers()
                Else
                    MsgBox("Please pick your seating",, "Error")
                End If
            Case 1
                'User selected Wicked as Play Choice
                If radOrchestra.Checked Then
                    decPricePerTicket = 149D
                    CalculateSubTotal()
                    TaxCalculation()
                    TotalCost()
                    DisplayAnswers()
                ElseIf radMezzanine.Checked Then
                    decPricePerTicket = 98D
                    CalculateSubTotal()
                    TaxCalculation()
                    TotalCost()
                    DisplayAnswers()
                Else
                    MsgBox("Please pick your seating",, "Error")
                End If
            Case 2
                'User selected Phantom of the Opera as Play Choice
                If radOrchestra.Checked Then
                    decPricePerTicket = 128D
                    CalculateSubTotal()
                    TaxCalculation()
                    TotalCost()
                    DisplayAnswers()
                ElseIf radMezzanine.Checked Then
                    decPricePerTicket = 82D
                    CalculateSubTotal()
                    TaxCalculation()
                    TotalCost()
                    DisplayAnswers()
                Else
                    MsgBox("Please pick your seating",, "Error")
                End If
        End Select
    End Sub

    Private Sub CalculateSubTotal()
        decSubTotal = decPricePerTicket * intNumberOfTickets
    End Sub

    Private Sub DisplayAnswers()
        'If we've gotten this far everything is peachy
        pnlInformationText.Visible = True
        pnlTotalAmounts.Visible = True
        'Display our panels!
        lblSubTotalAmount.Text = decSubTotal.ToString("C")
        lblTaxAmount.Text = decTaxAmount.ToString("C")
        lblFinalTotalAmount.Text = decTotal.ToString("C")
    End Sub


    ' One function to calculate the total cost
    Private Sub TotalCost()

        decTotal = decSubTotal + decTaxAmount

    End Sub

    ' One function to compute the tax regardless of play selected
    Private Sub TaxCalculation()

        decTaxAmount = _cdecTax * decSubTotal

    End Sub



End Class
